package com.lawmate.law_mate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
