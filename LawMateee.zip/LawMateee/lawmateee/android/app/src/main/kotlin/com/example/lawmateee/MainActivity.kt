package com.example.lawmateee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
